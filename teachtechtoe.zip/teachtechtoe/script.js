/* =====================================================================
   KICKOFF ARENA — top-down browser football game
   Pure HTML5 Canvas + vanilla JS. No image/audio assets required —
   players, ball and sound effects are all generated in code so the
   game runs standalone on desktop, tablet, Android and iPhone browsers.
   ===================================================================== */

(function () {
  "use strict";

  /* ------------------------------------------------------------------
     CANVAS + RESPONSIVE VIEWPORT
     A fixed "logical" pitch resolution is drawn every frame and scaled
     to fit whatever the real screen size is (desktop, tablet, phone).
     ------------------------------------------------------------------ */
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");

  const LOGICAL_W = 620;
  const LOGICAL_H = 1080;

  let dpr = Math.min(window.devicePixelRatio || 1, 2);
  let viewScale = 1, viewOffsetX = 0, viewOffsetY = 0;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = window.innerWidth;
    const h = window.innerHeight;
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = w + "px";
    canvas.style.height = h + "px";

    viewScale = Math.min((w * dpr) / LOGICAL_W, (h * dpr) / LOGICAL_H);
    viewOffsetX = ((w * dpr) - LOGICAL_W * viewScale) / 2;
    viewOffsetY = ((h * dpr) - LOGICAL_H * viewScale) / 2;
  }
  window.addEventListener("resize", resize);
  window.addEventListener("orientationchange", resize);
  resize();

  /* ------------------------------------------------------------------
     PITCH GEOMETRY (logical units)
     ------------------------------------------------------------------ */
  const PITCH = {
    x: 40, y: 40, width: 540, height: 1000,
    goalLeft: 225, goalRight: 395,
    postRadius: 5,
  };
  const GOAL_DEPTH = 22;
  const MID_X = PITCH.x + PITCH.width / 2;
  const MID_Y = PITCH.y + PITCH.height / 2;

  /* ------------------------------------------------------------------
     TINY UTILITIES
     ------------------------------------------------------------------ */
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const dist = (ax, ay, bx, by) => Math.hypot(ax - bx, ay - by);
  const lerp = (a, b, t) => a + (b - a) * t;
  const rand = (lo, hi) => lo + Math.random() * (hi - lo);

  /* ------------------------------------------------------------------
     WEB AUDIO — procedural sound effects (no mp3 files needed)
     ------------------------------------------------------------------ */
  let actx = null;
  function audio() {
    if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === "suspended") actx.resume();
    return actx;
  }
  function tone(freq, dur, type, gainStart, glideTo) {
    try {
      const ac = audio();
      const osc = ac.createOscillator();
      const gain = ac.createGain();
      osc.type = type || "sine";
      osc.frequency.setValueAtTime(freq, ac.currentTime);
      if (glideTo) osc.frequency.exponentialRampToValueAtTime(glideTo, ac.currentTime + dur);
      gain.gain.setValueAtTime(gainStart || 0.2, ac.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + dur);
      osc.connect(gain).connect(ac.destination);
      osc.start();
      osc.stop(ac.currentTime + dur);
    } catch (e) { /* audio not available — fail silently */ }
  }
  const sfx = {
    kick: () => tone(rand(180, 240), 0.09, "triangle", 0.18, 90),
    whistle: () => { tone(2200, 0.18, "square", 0.06); tone(2400, 0.14, "square", 0.05); },
    goal: () => {
      [0, 0.1, 0.2, 0.32].forEach((t, i) =>
        setTimeout(() => tone(440 + i * 120, 0.22, "sawtooth", 0.14), t * 1000)
      );
    },
    out: () => tone(160, 0.25, "square", 0.1, 90),
    ui: () => tone(520, 0.06, "sine", 0.12),
  };

  /* ------------------------------------------------------------------
     GAME / MATCH STATE
     ------------------------------------------------------------------ */
  let gameState = "MENU"; // MENU, PLAYING, PAUSED, CELEBRATE, FULLTIME
  let matchDuration = 300; // seconds — 5 min default
  let difficulty = "medium";
  let secondsLeft = matchDuration;
  let scoreBlue = 0, scoreRed = 0;
  let lastTouchTeam = null; // which team last touched the ball (for throw-ins / kickoffs)
  let clockAccumulator = 0;

  const DIFF_SETTINGS = {
    easy: { aiSpeed: 0.72, aiReact: 0.55, gkSpeed: 0.75 },
    medium: { aiSpeed: 0.9, aiReact: 0.78, gkSpeed: 0.92 },
    hard: { aiSpeed: 1.08, aiReact: 1.0, gkSpeed: 1.08 },
  };

  /* ------------------------------------------------------------------
     BALL
     ------------------------------------------------------------------ */
  class Ball {
    constructor() { this.reset(); }
    reset(x, y) {
      this.x = x ?? (PITCH.x + PITCH.width / 2);
      this.y = y ?? (PITCH.y + PITCH.height / 2);
      this.vx = 0; this.vy = 0;
      this.radius = 9;
      this.friction = 0.985;
      this.spin = 0;
      this.stuckTimer = 0;
      this.trail = [];
    }

    kick(vx, vy) { this.vx = vx; this.vy = vy; sfx.kick(); }

    update(dt) {
      this.x += this.vx * dt;
      this.y += this.vy * dt;
      this.vx *= Math.pow(this.friction, dt);
      this.vy *= Math.pow(this.friction, dt);
      this.spin += Math.hypot(this.vx, this.vy) * 0.02 * dt;

      const speed = Math.hypot(this.vx, this.vy);
      if (speed > 2.2) {
        this.trail.push({ x: this.x, y: this.y, a: 1 });
      }
      this.trail.forEach((t) => (t.a -= 0.08 * dt));
      this.trail = this.trail.filter((t) => t.a > 0);

      const topB = PITCH.y + this.radius;
      const bottomB = PITCH.y + PITCH.height - this.radius;
      const leftB = PITCH.x + this.radius;
      const rightB = PITCH.x + PITCH.width - this.radius;

      // Sidelines (left/right) always clamp — the ball can never leave
      // through the long edges of the pitch, it just bounces back in.
      if (this.x < leftB) { this.x = leftB; this.vx *= -0.7; sfx.kick(); }
      if (this.x > rightB) { this.x = rightB; this.vx *= -0.7; sfx.kick(); }

      const inGoalMouth = this.x > PITCH.goalLeft + this.radius && this.x < PITCH.goalRight - this.radius;

      if (inGoalMouth) {
        // A goal counts the instant the whole ball has crossed the line —
        // no gap is left between "still in play" and "goal", so the ball
        // can never rest in limbo behind the line without the game noticing.
        // Top goal belongs to RED, bottom goal belongs to BLUE.
        if (this.y < PITCH.y - this.radius) { triggerGoal("blue"); return; }
        if (this.y > PITCH.y + PITCH.height + this.radius) { triggerGoal("red"); return; }
        // else: ball is travelling through the goal mouth — let it move freely
      } else {
        if (this.y < topB) { this.y = topB; this.vy *= -0.7; sfx.kick(); }
        if (this.y > bottomB) { this.y = bottomB; this.vy *= -0.7; sfx.kick(); }
      }

      // --- OUT-OF-BOUNDS WATCHDOG ---
      // Safety net so the ball can *never* freeze the match: if it is ever
      // resting outside the playable rectangle (e.g. wedged in the goal
      // mouth without fully crossing the line) for more than ~0.6s, it is
      // automatically brought back into play, like a real throw-in / goal
      // kick, instead of leaving the game stuck.
      const outsidePlayable = this.x < leftB || this.x > rightB || this.y < topB || this.y > bottomB;
      if (outsidePlayable && speed < 0.6) {
        this.stuckTimer += dt;
        if (this.stuckTimer > 36) {
          this.stuckTimer = 0;
          this.x = clamp(this.x, leftB + 6, rightB - 6);
          this.y = clamp(this.y, topB + 6, bottomB - 6);
          const towardCenter = MID_Y - this.y;
          this.vy = Math.sign(towardCenter) * rand(2, 4);
          this.vx = rand(-2, 2);
          sfx.out();
          showBanner("OUT — RESTART", "out");
        }
      } else {
        this.stuckTimer = 0;
      }

      this.checkPost(PITCH.goalLeft, PITCH.y);
      this.checkPost(PITCH.goalRight, PITCH.y);
      this.checkPost(PITCH.goalLeft, PITCH.y + PITCH.height);
      this.checkPost(PITCH.goalRight, PITCH.y + PITCH.height);
    }

    checkPost(px, py) {
      const dx = this.x - px, dy = this.y - py;
      const d = Math.hypot(dx, dy);
      const minD = this.radius + PITCH.postRadius;
      if (d < minD && d > 0.001) {
        const nx = dx / d, ny = dy / d;
        this.x = px + nx * minD;
        this.y = py + ny * minD;
        const dot = this.vx * nx + this.vy * ny;
        this.vx -= 2 * dot * nx * 0.8;
        this.vy -= 2 * dot * ny * 0.8;
        sfx.kick();
      }
    }

    draw() {
      // motion trail
      this.trail.forEach((t) => {
        ctx.beginPath();
        ctx.arc(t.x, t.y, this.radius * 0.7, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${t.a * 0.35})`;
        ctx.fill();
      });

      ctx.beginPath();
      ctx.ellipse(this.x, this.y + this.radius * 0.9, this.radius * 1.1, this.radius * 0.42, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fill();

      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.spin);
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
      const g = ctx.createRadialGradient(-3, -3, 1, 0, 0, this.radius);
      g.addColorStop(0, "#ffffff");
      g.addColorStop(1, "#cfd3d8");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.strokeStyle = "#232323";
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = "#222";
      for (let i = 0; i < 5; i++) {
        const a = (i / 5) * Math.PI * 2;
        ctx.beginPath();
        ctx.arc(Math.cos(a) * this.radius * 0.5, Math.sin(a) * this.radius * 0.5, this.radius * 0.28, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------
     PLAYER
     ------------------------------------------------------------------ */
  const PLAYER_SYMBOL = "𖨆";

  class Player {
    constructor(team, role, number, isUser) {
      this.team = team; // 'blue' | 'red'
      this.role = role; // 'GK' | 'FIELD'
      this.number = number;
      this.isUser = !!isUser;
      this.radius = 15;
      this.baseSpeed = role === "GK" ? 2.55 : 2.9;
      this.x = 0; this.y = 0;
      this.homeX = 0; this.homeY = 0;
      this.vx = 0; this.vy = 0;
      this.facing = team === "blue" ? -Math.PI / 2 : Math.PI / 2;
      this.sprintTimer = 0;
      this.sprintCooldown = 0;
      this.kickCooldown = 0;
      this.hasBallGrace = 0;
    }

    get color() { return this.team === "blue" ? "#2f8fe0" : "#ff4d5e"; }
    get colorDark() { return this.team === "blue" ? "#1c4b91" : "#a11f2b"; }

    setHome(x, y) { this.homeX = x; this.homeY = y; }

    currentSpeed() {
      let s = this.baseSpeed;
      if (this.sprintTimer > 0) s *= 1.65;
      return s;
    }

    moveTowards(tx, ty, dt, speedMul) {
      const dx = tx - this.x, dy = ty - this.y;
      const d = Math.hypot(dx, dy);
      if (d < 1) return;
      const sp = this.currentSpeed() * (speedMul ?? 1);
      const stepX = (dx / d) * sp * dt;
      const stepY = (dy / d) * sp * dt;
      this.x += stepX;
      this.y += stepY;
      if (d > 2) this.facing = Math.atan2(dy, dx);
      this.vx = stepX; this.vy = stepY;
    }

    clampToPitch() {
      this.x = clamp(this.x, PITCH.x + this.radius, PITCH.x + PITCH.width - this.radius);
      this.y = clamp(this.y, PITCH.y + this.radius, PITCH.y + PITCH.height - this.radius);
    }

    update(dt) {
      if (this.sprintTimer > 0) this.sprintTimer -= dt / 60;
      if (this.sprintCooldown > 0) this.sprintCooldown -= dt / 60;
      if (this.kickCooldown > 0) this.kickCooldown -= dt / 60;
    }

    draw() {
      // shadow
      ctx.beginPath();
      ctx.ellipse(this.x, this.y + this.radius * 0.85, this.radius * 0.95, this.radius * 0.4, 0, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(0,0,0,0.32)";
      ctx.fill();

      // sprint trail glow
      if (this.sprintTimer > 0) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius + 7, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(55,214,122,0.28)";
        ctx.fill();
      }

      ctx.save();
      ctx.translate(this.x, this.y);

      // body disc (jersey colour) with subtle gradient for a chibi/3-D feel
      const g = ctx.createRadialGradient(-4, -6, 2, 0, 0, this.radius + 3);
      g.addColorStop(0, this.role === "GK" ? "#ffe27a" : this.color);
      g.addColorStop(1, this.role === "GK" ? "#c99a1e" : this.colorDark);
      ctx.beginPath();
      ctx.arc(0, 0, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,0.55)";
      ctx.stroke();

      // facing indicator (small nose triangle)
      ctx.rotate(this.facing);
      ctx.beginPath();
      ctx.moveTo(this.radius + 6, 0);
      ctx.lineTo(this.radius - 3, -5);
      ctx.lineTo(this.radius - 3, 5);
      ctx.closePath();
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.fill();
      ctx.restore();

      // player glyph
      ctx.save();
      ctx.font = '17px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif';
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "rgba(255,255,255,0.92)";
      ctx.shadowColor = "rgba(0,0,0,0.5)";
      ctx.shadowBlur = 2;
      ctx.fillText(PLAYER_SYMBOL, this.x, this.y - 1);
      ctx.restore();

      // shirt number
      ctx.save();
      ctx.font = "900 10px Arial";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#0e1420";
      ctx.fillText(this.number, this.x, this.y + this.radius + 10);
      ctx.restore();

      // user selection ring
      if (this.isUser) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius + 6, 0, Math.PI * 2);
        ctx.strokeStyle = "#ffcc33";
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }
  }

  /* ------------------------------------------------------------------
     TEAM SETUP
     ------------------------------------------------------------------ */
  let players = [];
  let userPlayer = null;
  let ball = new Ball();

  function buildTeams() {
    players = [];

    // BLUE (left side attacks right) — one is user-controlled
    players.push(new Player("blue", "GK", 1, false));
    players.push(new Player("blue", "FIELD", 4, false));
    players.push(new Player("blue", "FIELD", 7, false));
    players.push(new Player("blue", "FIELD", 10, true));

    // RED (CPU) attacks left
    players.push(new Player("red", "GK", 1, false));
    players.push(new Player("red", "FIELD", 5, false));
    players.push(new Player("red", "FIELD", 9, false));
    players.push(new Player("red", "FIELD", 11, false));

    userPlayer = players.find((p) => p.isUser);
    layoutFormation();
  }

  function layoutFormation() {
    const blue = players.filter((p) => p.team === "blue");
    const red = players.filter((p) => p.team === "red");

    // BLUE defends the bottom goal and attacks upward (toward smaller y)
    blue[0].setHome(MID_X, PITCH.y + PITCH.height - 30); // GK
    blue[1].setHome(MID_X - 120, PITCH.y + PITCH.height - 230);
    blue[2].setHome(MID_X + 120, PITCH.y + PITCH.height - 230);
    blue[3].setHome(MID_X, PITCH.y + PITCH.height - 420);

    // RED defends the top goal and attacks downward (toward larger y)
    red[0].setHome(MID_X, PITCH.y + 30); // GK
    red[1].setHome(MID_X - 120, PITCH.y + 230);
    red[2].setHome(MID_X + 120, PITCH.y + 230);
    red[3].setHome(MID_X, PITCH.y + 420);

    players.forEach((p) => { p.x = p.homeX; p.y = p.homeY; });
  }

  function kickoffPositions() {
    layoutFormation();
    ball.reset();
    ball.vx = 0; ball.vy = 0;
  }

  /* ------------------------------------------------------------------
     INPUT — KEYBOARD
     ------------------------------------------------------------------ */
  const keys = { up: false, down: false, left: false, right: false };
  let sprintHeld = false;

  window.addEventListener("keydown", (e) => {
    if (["ArrowUp", "KeyW"].includes(e.code)) keys.up = true;
    if (["ArrowDown", "KeyS"].includes(e.code)) keys.down = true;
    if (["ArrowLeft", "KeyA"].includes(e.code)) keys.left = true;
    if (["ArrowRight", "KeyD"].includes(e.code)) keys.right = true;
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") sprintHeld = true;
    if (e.code === "Space") { e.preventDefault(); attemptShoot(); }
    if (e.code === "ControlLeft" || e.code === "ControlRight") attemptPass();
    if (e.code === "Escape" || e.code === "KeyP") togglePause();
  });
  window.addEventListener("keyup", (e) => {
    if (["ArrowUp", "KeyW"].includes(e.code)) keys.up = false;
    if (["ArrowDown", "KeyS"].includes(e.code)) keys.down = false;
    if (["ArrowLeft", "KeyA"].includes(e.code)) keys.left = false;
    if (["ArrowRight", "KeyD"].includes(e.code)) keys.right = false;
    if (e.code === "ShiftLeft" || e.code === "ShiftRight") sprintHeld = false;
  });

  /* ------------------------------------------------------------------
     INPUT — VIRTUAL JOYSTICK (touch + mouse)
     ------------------------------------------------------------------ */
  const joyZone = document.getElementById("joystick-zone");
  const joyStick = document.getElementById("joystick-stick");
  const joystick = { active: false, id: null, dx: 0, dy: 0 };

  function joyGeometry() {
    const r = joyZone.getBoundingClientRect();
    return { cx: r.left + r.width / 2, cy: r.top + r.height / 2, radius: r.width * 0.38 };
  }
  function joyStart(id, clientX, clientY) {
    joystick.active = true; joystick.id = id;
    joyUpdate(clientX, clientY);
  }
  function joyUpdate(clientX, clientY) {
    const { cx, cy, radius } = joyGeometry();
    let dx = clientX - cx, dy = clientY - cy;
    const d = Math.hypot(dx, dy);
    const max = radius;
    if (d > max) { dx = (dx / d) * max; dy = (dy / d) * max; }
    joystick.dx = dx / max; joystick.dy = dy / max;
    joyStick.style.transform = `translate(-50%, -50%) translate(${dx}px, ${dy}px)`;
  }
  function joyEnd() {
    joystick.active = false; joystick.id = null;
    joystick.dx = 0; joystick.dy = 0;
    joyStick.style.transform = "translate(-50%, -50%)";
  }
  joyZone.addEventListener("touchstart", (e) => {
    e.preventDefault();
    const t = e.changedTouches[0];
    joyStart(t.identifier, t.clientX, t.clientY);
  }, { passive: false });
  joyZone.addEventListener("touchmove", (e) => {
    e.preventDefault();
    for (const t of e.changedTouches) if (t.identifier === joystick.id) joyUpdate(t.clientX, t.clientY);
  }, { passive: false });
  window.addEventListener("touchend", (e) => {
    for (const t of e.changedTouches) if (t.identifier === joystick.id) joyEnd();
  });
  // mouse fallback (desktop testing)
  joyZone.addEventListener("mousedown", (e) => { joyStart("mouse", e.clientX, e.clientY); });
  window.addEventListener("mousemove", (e) => { if (joystick.active) joyUpdate(e.clientX, e.clientY); });
  window.addEventListener("mouseup", () => { if (joystick.id === "mouse") joyEnd(); });

  /* ------------------------------------------------------------------
     INPUT — ACTION BUTTONS
     ------------------------------------------------------------------ */
  const btnShoot = document.getElementById("btn-shoot");
  const btnPass = document.getElementById("btn-pass");
  const btnSprint = document.getElementById("btn-sprint");

  function bindPress(el, downFn, upFn) {
    el.addEventListener("touchstart", (e) => { e.preventDefault(); downFn(); }, { passive: false });
    el.addEventListener("mousedown", (e) => { e.preventDefault(); downFn(); });
    if (upFn) {
      el.addEventListener("touchend", (e) => { e.preventDefault(); upFn(); });
      el.addEventListener("mouseup", (e) => { e.preventDefault(); upFn(); });
    }
  }
  bindPress(btnShoot, attemptShoot);
  bindPress(btnPass, attemptPass);
  bindPress(btnSprint, () => { sprintHeld = true; btnSprint.classList.add("active"); },
    () => { sprintHeld = false; btnSprint.classList.remove("active"); });

  /* ------------------------------------------------------------------
     BALL POSSESSION / ACTIONS
     ------------------------------------------------------------------ */
  function nearestToBall(team) {
    let best = null, bestD = Infinity;
    players.filter((p) => p.team === team).forEach((p) => {
      const d = dist(p.x, p.y, ball.x, ball.y);
      if (d < bestD) { bestD = d; best = p; }
    });
    return best;
  }

  function userHasBall() {
    return dist(userPlayer.x, userPlayer.y, ball.x, ball.y) < userPlayer.radius + ball.radius + 6;
  }

  function attemptShoot() {
    if (gameState !== "PLAYING") return;
    if (!userHasBall() || userPlayer.kickCooldown > 0) return;
    const goalY = PITCH.y; // blue always attacks the top-hand goal
    const goalX = (PITCH.goalLeft + PITCH.goalRight) / 2 + rand(-14, 14);
    const angle = Math.atan2(goalY - ball.y, goalX - ball.x);
    const power = 9.5;
    ball.kick(Math.cos(angle) * power, Math.sin(angle) * power);
    lastTouchTeam = "blue";
    userPlayer.kickCooldown = 0.35;
  }

  function attemptPass() {
    if (gameState !== "PLAYING") return;
    if (!userHasBall() || userPlayer.kickCooldown > 0) return;
    const mates = players.filter((p) => p.team === "blue" && p !== userPlayer);
    let target = mates[0], bestScore = -Infinity;
    mates.forEach((m) => {
      const forwardness = userPlayer.y - m.y; // smaller y = further forward for blue
      const d = dist(m.x, m.y, userPlayer.x, userPlayer.y);
      const score = forwardness - d * 0.3;
      if (score > bestScore) { bestScore = score; target = m; }
    });
    const angle = Math.atan2(target.y - ball.y, target.x - ball.x);
    const power = clamp(dist(target.x, target.y, ball.x, ball.y) * 0.045, 4, 7.5);
    ball.kick(Math.cos(angle) * power, Math.sin(angle) * power);
    lastTouchTeam = "blue";
    userPlayer.kickCooldown = 0.3;
  }

  function attemptSprint() {
    if (userPlayer.sprintCooldown <= 0) {
      userPlayer.sprintTimer = 1.4;
      userPlayer.sprintCooldown = 3;
    }
  }

  /* ------------------------------------------------------------------
     UPDATE — USER PLAYER
     ------------------------------------------------------------------ */
  function updateUser(dt) {
    let dx = 0, dy = 0;
    if (keys.up) dy -= 1;
    if (keys.down) dy += 1;
    if (keys.left) dx -= 1;
    if (keys.right) dx += 1;
    if (joystick.active) { dx = joystick.dx; dy = joystick.dy; }

    const mag = Math.hypot(dx, dy);
    if (sprintHeld) attemptSprint();

    if (mag > 0.08) {
      const nx = dx / mag, ny = dy / mag;
      const sp = userPlayer.currentSpeed();
      userPlayer.x += nx * sp * Math.min(mag, 1) * dt;
      userPlayer.y += ny * sp * Math.min(mag, 1) * dt;
      userPlayer.facing = Math.atan2(ny, nx);
    }
    userPlayer.clampToPitch();

    // gentle dribble: ball nudges along in front of the user when close & slow
    const d = dist(userPlayer.x, userPlayer.y, ball.x, ball.y);
    if (d < userPlayer.radius + ball.radius + 4 && Math.hypot(ball.vx, ball.vy) < 6) {
      const push = 0.55;
      ball.vx = lerp(ball.vx, Math.cos(userPlayer.facing) * 3.2, push * dt * 0.25);
      ball.vy = lerp(ball.vy, Math.sin(userPlayer.facing) * 3.2, push * dt * 0.25);
      lastTouchTeam = "blue";
    }
  }

  /* ------------------------------------------------------------------
     UPDATE — AI (teammates + CPU team)
     ------------------------------------------------------------------ */
  function updateAI(p, dt) {
    const diff = DIFF_SETTINGS[difficulty];
    const isCpuTeam = p.team === "red";
    const speedMul = p.role === "GK" ? diff.gkSpeed : diff.aiSpeed;

    if (p.role === "GK") {
      const goalY = p.team === "blue" ? PITCH.y + PITCH.height - 28 : PITCH.y + 28;
      const ballNear = dist(ball.x, ball.y, (PITCH.goalLeft + PITCH.goalRight) / 2, goalY) < 260;
      const targetX = clamp(ball.x, PITCH.goalLeft + 18, PITCH.goalRight - 18);
      const targetY = ballNear ? goalY + (p.team === "blue" ? -14 : 14) : goalY;
      p.moveTowards(targetX, targetY, dt, speedMul);

      // GK clears the ball if it's right next to him
      if (dist(p.x, p.y, ball.x, ball.y) < p.radius + ball.radius + 5 && p.kickCooldown <= 0) {
        const upfieldY = p.team === "blue" ? PITCH.y + PITCH.height * 0.45 : PITCH.y + PITCH.height * 0.55;
        const angle = Math.atan2(upfieldY - ball.y, (MID_X + rand(-80, 80)) - ball.x);
        ball.kick(Math.cos(angle) * 7, Math.sin(angle) * 7);
        lastTouchTeam = p.team;
        p.kickCooldown = 0.6;
      }
      return;
    }

    const closest = nearestToBall(p.team);
    const isClosest = closest === p;
    // "My side" for red (defends top) excludes the deep bottom third near
    // blue's goal; for blue (defends bottom) excludes the deep top third.
    const ballOnMySide = isCpuTeam ? ball.y < PITCH.y + PITCH.height * 0.65 : ball.y > PITCH.y + PITCH.height * 0.35;

    if (isClosest && (ballOnMySide || dist(p.x, p.y, ball.x, ball.y) < 150)) {
      // Chase and attack the ball
      p.moveTowards(ball.x, ball.y, dt, speedMul);

      if (dist(p.x, p.y, ball.x, ball.y) < p.radius + ball.radius + 5 && p.kickCooldown <= 0) {
        const enemyGoalY = isCpuTeam ? PITCH.y + PITCH.height : PITCH.y;
        const enemyGoalX = (PITCH.goalLeft + PITCH.goalRight) / 2;
        const distToGoal = dist(p.x, p.y, enemyGoalX, enemyGoalY);

        if (Math.random() < diff.aiReact) {
          let aimX = enemyGoalX + rand(-40, 40), aimY = enemyGoalY;
          let power = 6.5;
          if (distToGoal > 260) {
            // pass toward a forward teammate instead of a long hopeless shot
            const mates = players.filter((m) => m.team === p.team && m !== p);
            let target = mates[0], bestScore = -Infinity;
            mates.forEach((m) => {
              const forwardness = isCpuTeam ? m.y - p.y : p.y - m.y;
              const score = forwardness - dist(m.x, m.y, p.x, p.y) * 0.3;
              if (score > bestScore) { bestScore = score; target = m; }
            });
            aimX = target.x; aimY = target.y;
            power = 5.5;
          } else {
            power = 8.5;
          }
          const angle = Math.atan2(aimY - ball.y, aimX - ball.x);
          ball.kick(Math.cos(angle) * power, Math.sin(angle) * power);
          lastTouchTeam = p.team;
          p.kickCooldown = 0.4;
        }
      }
    } else {
      // Hold shape / support position relative to the ball
      const biasY = isCpuTeam ? 60 : -60;
      const targetX = clamp((ball.x + p.homeX) / 2, PITCH.x + 40, PITCH.x + PITCH.width - 40);
      const targetY = clamp((ball.y + p.homeY * 1.4) / 2.4 + biasY * 0.2, PITCH.y + 40, PITCH.y + PITCH.height - 40);
      p.moveTowards(targetX, targetY, dt, speedMul * 0.85);
    }
    p.clampToPitch();
  }

  /* ------------------------------------------------------------------
     GOAL / OUT-OF-BOUNDS BANNER + MATCH FLOW
     ------------------------------------------------------------------ */
  const bannerEl = document.getElementById("hud-banner");
  let bannerTimeout = null;
  function showBanner(text, variant) {
    clearTimeout(bannerTimeout);
    bannerEl.textContent = text;
    bannerEl.className = variant === "out" ? "banner--out" : "";
    requestAnimationFrame(() => bannerEl.classList.add("show"));
    bannerTimeout = setTimeout(() => bannerEl.classList.remove("show"), 1500);
  }

  function triggerGoal(scoringTeam) {
    if (gameState !== "PLAYING") return;
    gameState = "CELEBRATE";
    sfx.whistle();
    sfx.goal();

    if (scoringTeam === "blue") scoreBlue++; else scoreRed++;
    document.getElementById("score-blue").textContent = scoreBlue;
    document.getElementById("score-red").textContent = scoreRed;

    showBanner(`GOAL! ${scoringTeam === "blue" ? "BLUE FC" : "RED UTD"}`, "goal");

    setTimeout(() => {
      kickoffPositions();
      if (secondsLeft > 0) {
        gameState = "PLAYING";
        sfx.whistle();
      }
    }, 1500);
  }

  /* ------------------------------------------------------------------
     TIMER
     ------------------------------------------------------------------ */
  const clockEl = document.getElementById("match-clock");
  const timerBox = document.getElementById("hud-timer");
  function updateClockDisplay() {
    const s = Math.max(0, Math.ceil(secondsLeft));
    const m = String(Math.floor(s / 60)).padStart(2, "0");
    const ss = String(s % 60).padStart(2, "0");
    clockEl.textContent = `${m}:${ss}`;
    timerBox.classList.toggle("low-time", s <= 30 && s > 0);
  }

  function tickClock(dt) {
    if (gameState !== "PLAYING" && gameState !== "CELEBRATE") return;
    secondsLeft -= dt;
    if (secondsLeft <= 0) {
      secondsLeft = 0;
      updateClockDisplay();
      fullTime();
      return;
    }
    updateClockDisplay();
  }

  function fullTime() {
    gameState = "FULLTIME";
    sfx.whistle();
    document.getElementById("ft-score-blue").textContent = scoreBlue;
    document.getElementById("ft-score-red").textContent = scoreRed;
    const tag = document.getElementById("ft-result-tag");
    const headline = document.getElementById("ft-headline");
    if (scoreBlue === scoreRed) { tag.textContent = "FULL TIME"; headline.textContent = "IT'S A DRAW"; }
    else if (scoreBlue > scoreRed) { tag.textContent = "FULL TIME · VICTORY"; headline.textContent = "BLUE FC WINS!"; }
    else { tag.textContent = "FULL TIME · DEFEAT"; headline.textContent = "RED UTD WINS"; }
    document.getElementById("overlay-fulltime").style.display = "flex";
  }

  /* ------------------------------------------------------------------
     PAUSE
     ------------------------------------------------------------------ */
  const pauseModalEl = document.getElementById("pauseModal");
  const pauseModal = new bootstrap.Modal(pauseModalEl);
  let stateBeforePause = "PLAYING";

  function togglePause() {
    if (gameState === "PLAYING" || gameState === "CELEBRATE") {
      stateBeforePause = gameState;
      gameState = "PAUSED";
      pauseModal.show();
    } else if (gameState === "PAUSED") {
      resumeGame();
    }
  }
  function resumeGame() {
    gameState = stateBeforePause;
    pauseModal.hide();
  }
  document.getElementById("btn-pause").addEventListener("click", () => { sfx.ui(); togglePause(); });
  document.getElementById("btn-resume").addEventListener("click", () => { sfx.ui(); resumeGame(); });
  document.getElementById("btn-quit").addEventListener("click", () => {
    sfx.ui();
    pauseModal.hide();
    gameState = "MENU";
    document.getElementById("overlay-start").style.display = "flex";
  });

  /* ------------------------------------------------------------------
     FULLSCREEN
     ------------------------------------------------------------------ */
  document.getElementById("btn-fullscreen").addEventListener("click", () => {
    sfx.ui();
    const el = document.documentElement;
    if (!document.fullscreenElement) {
      (el.requestFullscreen || el.webkitRequestFullscreen || el.msRequestFullscreen || function () {}).call(el);
    } else {
      (document.exitFullscreen || document.webkitExitFullscreen || document.msExitFullscreen || function () {}).call(document);
    }
  });

  /* ------------------------------------------------------------------
     START / OPTIONS OVERLAY
     ------------------------------------------------------------------ */
  document.querySelectorAll("[data-duration]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("[data-duration]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      matchDuration = parseInt(btn.dataset.duration, 10);
      sfx.ui();
    });
  });
  document.querySelectorAll("[data-diff]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("[data-diff]").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      difficulty = btn.dataset.diff;
      sfx.ui();
    });
  });

  function startMatch() {
    audio(); // unlock WebAudio on user gesture
    scoreBlue = 0; scoreRed = 0;
    document.getElementById("score-blue").textContent = "0";
    document.getElementById("score-red").textContent = "0";
    secondsLeft = matchDuration;
    updateClockDisplay();
    buildTeams();
    document.getElementById("overlay-start").style.display = "none";
    document.getElementById("overlay-fulltime").style.display = "none";
    gameState = "PLAYING";
    sfx.whistle();
  }

  document.getElementById("btn-kickoff").addEventListener("click", startMatch);
  document.getElementById("btn-rematch").addEventListener("click", startMatch);

  /* ------------------------------------------------------------------
     FIELD RENDERING
     ------------------------------------------------------------------ */
  function drawPitch() {
    // outer surrounds
    ctx.fillStyle = "#276a34";
    ctx.fillRect(0, 0, LOGICAL_W, LOGICAL_H);

    // mowed stripes (horizontal bands, since the pitch now runs top-to-bottom)
    const stripeH = PITCH.height / 14;
    for (let i = 0; i < 14; i++) {
      ctx.fillStyle = i % 2 === 0 ? "#3fae52" : "#379a49";
      ctx.fillRect(PITCH.x, PITCH.y + i * stripeH, PITCH.width, stripeH);
    }

    ctx.strokeStyle = "rgba(255,255,255,0.85)";
    ctx.lineWidth = 3;
    ctx.strokeRect(PITCH.x, PITCH.y, PITCH.width, PITCH.height);

    // halfway line + centre circle
    ctx.beginPath();
    ctx.moveTo(PITCH.x, PITCH.y + PITCH.height / 2);
    ctx.lineTo(PITCH.x + PITCH.width, PITCH.y + PITCH.height / 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(PITCH.x + PITCH.width / 2, PITCH.y + PITCH.height / 2, 62, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(PITCH.x + PITCH.width / 2, PITCH.y + PITCH.height / 2, 3, 0, Math.PI * 2);
    ctx.fillStyle = "#fff";
    ctx.fill();

    // penalty boxes (span the goal width, extend down from the goal line)
    const boxSpan = 260, boxDepth = 140;
    const boxX = PITCH.x + (PITCH.width - boxSpan) / 2;
    ctx.strokeRect(boxX, PITCH.y, boxSpan, boxDepth);
    ctx.strokeRect(boxX, PITCH.y + PITCH.height - boxDepth, boxSpan, boxDepth);
    const gBoxSpan = 140, gBoxDepth = 55;
    const gBoxX = PITCH.x + (PITCH.width - gBoxSpan) / 2;
    ctx.strokeRect(gBoxX, PITCH.y, gBoxSpan, gBoxDepth);
    ctx.strokeRect(gBoxX, PITCH.y + PITCH.height - gBoxDepth, gBoxSpan, gBoxDepth);

    // corner arcs
    [[PITCH.x, PITCH.y, 0, Math.PI / 2], [PITCH.x + PITCH.width, PITCH.y, Math.PI / 2, Math.PI],
     [PITCH.x, PITCH.y + PITCH.height, -Math.PI / 2, 0], [PITCH.x + PITCH.width, PITCH.y + PITCH.height, Math.PI, Math.PI * 1.5]]
      .forEach(([cx, cy, a1, a2]) => { ctx.beginPath(); ctx.arc(cx, cy, 10, a1, a2); ctx.stroke(); });

    // goal nets (behind the goal line, above the top edge and below the bottom edge)
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.fillRect(PITCH.goalLeft, PITCH.y - GOAL_DEPTH, PITCH.goalRight - PITCH.goalLeft, GOAL_DEPTH);
    ctx.fillRect(PITCH.goalLeft, PITCH.y + PITCH.height, PITCH.goalRight - PITCH.goalLeft, GOAL_DEPTH);
    ctx.strokeStyle = "rgba(255,255,255,0.5)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const gy = PITCH.y - GOAL_DEPTH + (GOAL_DEPTH / 4) * i;
      ctx.beginPath(); ctx.moveTo(PITCH.goalLeft, gy); ctx.lineTo(PITCH.goalRight, gy); ctx.stroke();
      const gy2 = PITCH.y + PITCH.height + (GOAL_DEPTH / 4) * i;
      ctx.beginPath(); ctx.moveTo(PITCH.goalLeft, gy2); ctx.lineTo(PITCH.goalRight, gy2); ctx.stroke();
    }

    // goal posts
    ctx.lineWidth = 3;
    ctx.strokeStyle = "#ffffff";
    [PITCH.goalLeft, PITCH.goalRight].forEach((gx) => {
      ctx.beginPath(); ctx.arc(gx, PITCH.y, PITCH.postRadius, 0, Math.PI * 2); ctx.fillStyle = "#fff"; ctx.fill();
      ctx.beginPath(); ctx.arc(gx, PITCH.y + PITCH.height, PITCH.postRadius, 0, Math.PI * 2); ctx.fill();
    });
  }

  /* ------------------------------------------------------------------
     MAIN LOOP
     ------------------------------------------------------------------ */
  let lastTs = performance.now();

  function frame(ts) {
    const dtMs = Math.min(ts - lastTs, 48);
    lastTs = ts;
    const dt = dtMs / 16.6667; // normalise to ~60fps steps

    if (gameState === "PLAYING") {
      updateUser(dt);
      players.forEach((p) => { if (!p.isUser) updateAI(p, dt); p.update(dt); });
      ball.update(dt);
      tickClock(dtMs / 1000);
    } else if (gameState === "CELEBRATE") {
      tickClock(dtMs / 1000);
    }

    // ---- draw ----
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); // reset then apply logical->screen transform
    ctx.setTransform(viewScale, 0, 0, viewScale, viewOffsetX, viewOffsetY);
    ctx.clearRect(-viewOffsetX / viewScale, -viewOffsetY / viewScale, canvas.width / viewScale, canvas.height / viewScale);

    drawPitch();
    if (players.length) {
      players.slice().sort((a, b) => a.y - b.y).forEach((p) => p.draw());
      ball.draw();
    }

    requestAnimationFrame(frame);
  }

  updateClockDisplay();
  requestAnimationFrame(frame);
})();
