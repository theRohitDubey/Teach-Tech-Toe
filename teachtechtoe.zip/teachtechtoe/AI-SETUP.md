# AI tools setup for aud.html

The text summarizer, sentiment analyzer, writing-pattern review, and speech-to-text helper actions use Netlify Functions. The functions forward requests to self-hosted open-source services; no model keys are stored in the page.

## Ollama: text tools

1. Install Ollama on a machine that can remain available while the site is used.
2. Download a model suitable for your hardware and required languages. Check that model's license before public or commercial use.
3. Deploy this folder to Netlify; `netlify.toml` points Netlify to `netlify/functions`.
4. Set `OLLAMA_BASE_URL` (the Ollama base URL reachable from Netlify, without a trailing slash) and `OLLAMA_MODEL` (installed model name) in Netlify site environment settings. If the Ollama gateway requires a bearer token, also set `OLLAMA_API_TOKEN`.
5. Redeploy and visit over HTTPS. A direct `file://` open cannot call Netlify Functions.

## Piper: generated text-to-speech audio

On a private host with Piper installed, run `python -m pip install 'piper-tts[http]'`, download a voice with `python -m piper.download_voices <voice-name>`, then start `python -m piper.http_server -m <voice-name> --host 0.0.0.0 --port 5000`. Set Netlify `PIPER_BASE_URL` to the private service base URL. If your gateway requires a bearer token, set `PIPER_API_TOKEN`. Optionally set `PIPER_VOICE_EN` and `PIPER_VOICE_HI` to voice IDs available on that server. The page's Voice engine selector lets users choose Piper or the existing device voice. Each voice has its own license; check it before publishing audio.

## Faster-Whisper: audio file transcription

The small FastAPI adapter in `ai-services/faster-whisper` accepts audio at `/transcribe` and runs Faster-Whisper. Install its requirements, then launch it from that folder with `uvicorn app:app --host 0.0.0.0 --port 8000`. Set Netlify `FASTER_WHISPER_URL` to that service's base URL. Set the same random secret as `FASTER_WHISPER_TOKEN` in Netlify and `WHISPER_API_TOKEN` on the service to require bearer authentication. The page accepts audio files up to 4 MB for transcription. The existing live microphone tool remains available as a browser speech-recognition fallback.

## Network and privacy

Netlify functions cannot reach `localhost` on your PC. Do not expose unauthenticated Ollama, Piper, or transcription ports to the public internet. Put the services behind an authenticated private gateway or private network reachable by Netlify, and add authentication/rate limits before allowing anonymous use. Avoid uploading confidential text or recordings to a public service.

## Image and video tools

- OCR already runs with Tesseract.js in the browser.
- Image generation currently calls an external hosted image endpoint.
- Image-to-video, text-to-video, code-to-video, and slides-to-video currently animate content on a canvas and record it; the page now identifies these as animations. Real AI video or private image generation needs a separately hosted ComfyUI workflow and compatible model on GPU-capable hardware. Model workflows are not interchangeable, so choose a model/workflow before wiring its API into the page.
- The live class embeds Jitsi Meet. Cross-device rooms require the page to be hosted at a reachable web address.

Software and model licenses are separate. Review all model and voice licenses before publishing generated results.
