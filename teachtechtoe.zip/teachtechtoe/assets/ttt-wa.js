/* Teach Tech Toe - WhatsApp verification after sign-up */
window.TTT_WA_NUMBER="918878695818"; /* business WhatsApp (country code, no +) */
window.tttVerify=function(type,fields){
  var ref="TTT-"+(type==="trainer"?"T":"S")+"-"+Date.now().toString().slice(-6);
  var lines=Object.keys(fields).map(function(k){return "*"+k+":* "+fields[k]});
  var msg="*"+(type==="trainer"?"TRAINER":"STUDENT")+" REGISTRATION – Verify me*\nRef: "+ref+"\n\n"+lines.join("\n")+"\n\nPlease verify my registration on WhatsApp. Thank you!";
  var url="https://wa.me/"+window.TTT_WA_NUMBER+"?text="+encodeURIComponent(msg);
  try{localStorage.setItem("ttt_wa",JSON.stringify({url:url,ref:ref,type:type}))}catch(e){}
  window.open(url,"_blank");
  return {ref:ref,url:url};
};
window.tttPhoneOk=function(v){return /^[6-9]\d{9}$/.test(v)};
window.tttNameOk=function(v){return /^[A-Za-z][A-Za-z .'-]{1,59}$/.test(v)};
