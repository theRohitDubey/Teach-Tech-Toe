/* Teach Tech Toe - phone audio fixes
   1) Text-to-speech: Android Chrome drops speak() right after cancel(), long text stops
      after a few seconds, the voice list is empty at first, and a missing language voice
      (e.g. Hindi) is silent with no message. This wraps speechSynthesis to handle all four.
   2) Game sounds: phones start Web Audio "suspended" until a tap, so this resumes every
      AudioContext on the first touch / click.
   Load this BEFORE the page's own scripts (right after <head>). */
(function () {
  var ua = navigator.userAgent || '';
  var isIOS = /iPhone|iPad|iPod/i.test(ua);

  /* ---------- small toast ---------- */
  function toast(html) {
    try {
      var old = document.getElementById('tttAudioToast');
      if (old) old.remove();
      var d = document.createElement('div');
      d.id = 'tttAudioToast';
      d.setAttribute('role', 'status');
      d.style.cssText = 'position:fixed;left:50%;bottom:84px;transform:translateX(-50%);max-width:92vw;' +
        'background:#0b1220;color:#fff;padding:12px 16px;border-radius:14px;font:500 13.5px/1.45 Poppins,Segoe UI,sans-serif;' +
        'box-shadow:0 10px 30px rgba(0,0,0,.45);z-index:2147483000;text-align:center;border:1px solid #ff6b1a';
      d.innerHTML = html;
      (document.body || document.documentElement).appendChild(d);
      setTimeout(function () { if (d.parentNode) d.remove(); }, 9000);
    } catch (e) {}
  }

  /* ---------- 1. speech synthesis ---------- */
  var ss = window.speechSynthesis;
  if (ss && window.SpeechSynthesisUtterance && !ss.__tttPatched) {
    ss.__tttPatched = true;
    var oSpeak = ss.speak.bind(ss), oCancel = ss.cancel.bind(ss);
    var queue = [], timer = null, lastCancel = 0, waitedForVoices = false, warned = {};
    var NAMES = { hi: 'Hindi', en: 'English', mr: 'Marathi', bn: 'Bengali', ta: 'Tamil', te: 'Telugu', gu: 'Gujarati' };

    function norm(l) { return String(l || '').toLowerCase().replace('_', '-'); }

    function voiceFor(lang) {
      var v = ss.getVoices ? ss.getVoices() : [];
      if (!v.length) return null;
      lang = norm(lang) || 'en-us';
      var pre = lang.split('-')[0];
      var exact = v.filter(function (x) { return norm(x.lang) === lang; });
      var same = v.filter(function (x) { return norm(x.lang).split('-')[0] === pre; });
      var pool = exact.length ? exact : same;
      if (!pool.length) return null;
      var def = pool.filter(function (x) { return x.default; });
      return def[0] || pool[0];
    }

    function prep(u) {
      try {
        if (u.voice) return;
        var lang = u.lang || (document.documentElement.lang || 'en-IN');
        var v = voiceFor(lang);
        if (v) { u.voice = v; if (!u.lang) u.lang = v.lang; return; }
        var all = ss.getVoices ? ss.getVoices() : [];
        var pre = norm(lang).split('-')[0];
        if (all.length && !warned[pre]) {
          warned[pre] = 1;
          var nm = NAMES[pre] || pre.toUpperCase();
          var msg = 'No ' + nm + ' voice is installed on this phone, so it cannot be read aloud. ' +
            'Install it in <b>Settings &rarr; Language &rarr; Text-to-speech</b>.';
          if (pre !== 'en' && u.text) {
            msg += ' Or <a style="color:#ff9800;font-weight:700" target="_blank" rel="noopener" href="https://translate.google.com/?sl=' +
              pre + '&tl=' + pre + '&op=translate&text=' + encodeURIComponent(String(u.text).slice(0, 800)) + '">listen with Google Translate</a>.';
          }
          toast(msg);
        }
      } catch (e) {}
    }

    function split(text) {
      var parts = String(text).match(/[^.!?\u0964\n]+[.!?\u0964]*\s*/g) || [String(text)];
      var out = [], cur = '';
      parts.forEach(function (p) {
        if (cur && (cur + p).length > 170) { out.push(cur); cur = p; } else { cur += p; }
      });
      if (cur.trim()) out.push(cur);
      var final = [];
      out.forEach(function (s) {
        while (s.length > 220) {
          var cut = s.lastIndexOf(' ', 200);
          if (cut < 80) cut = 200;
          final.push(s.slice(0, cut));
          s = s.slice(cut);
        }
        if (s.trim()) final.push(s);
      });
      return final;
    }

    var keep = window.__tttKeep = window.__tttKeep || [];
    function hold(u) {                                 /* Chrome Android drops speech if the utterance is garbage-collected */
      keep.push(u);
      var free = function () { var i = keep.indexOf(u); if (i > -1) keep.splice(i, 1); };
      var oe = u.onend, er = u.onerror;
      u.onend = function (e) { free(); if (oe) oe.call(u, e); };
      u.onerror = function (e) { free(); if (er) er.call(u, e); };
    }
    function run() {
      try { if (ss.paused) ss.resume(); } catch (e) {}
      while (queue.length) {
        var u = queue.shift();
        prep(u);
        hold(u);
        oSpeak(u);
      }
    }

    function flush() {
      if (timer) return;
      var wait = 0;
      if (!isIOS) {
        var since = Date.now() - lastCancel;
        if (since < 160) wait = 160 - since;          /* Android: cancel() then speak() is dropped */
      }
      var noVoices = !(ss.getVoices && ss.getVoices().length);
      if (noVoices && !waitedForVoices) { waitedForVoices = true; wait = Math.max(wait, 400); }  /* voice list loads late */
      if (!wait) { run(); return; }                    /* keep the tap gesture when no wait is needed */
      timer = setTimeout(function () { timer = null; run(); }, wait);
    }

    ss.cancel = function () {
      queue.length = 0;
      if (timer) { clearTimeout(timer); timer = null; }
      lastCancel = Date.now();
      oCancel();
    };

    ss.speak = function (u) {
      if (!(u instanceof window.SpeechSynthesisUtterance)) return oSpeak(u);
      var text = u.text || '';
      if (text.length > 200) {                         /* long text stops mid-way on phones: speak in pieces */
        var pieces = split(text);
        if (pieces.length > 1) {
          pieces.forEach(function (t, i) {
            var c = new window.SpeechSynthesisUtterance(t);
            c.lang = u.lang; c.rate = u.rate; c.pitch = u.pitch; c.volume = u.volume;
            if (u.voice) c.voice = u.voice;
            if (i === 0) c.onstart = function (e) { if (u.onstart) u.onstart(e); };
            if (i === pieces.length - 1) c.onend = function (e) { if (u.onend) u.onend(e); };
            c.onerror = function (e) { if (u.onerror) u.onerror(e); };
            queue.push(c);
          });
          flush();
          return;
        }
      }
      queue.push(u);
      flush();
    };

    if (ss.addEventListener) { try { ss.addEventListener('voiceschanged', function () {}); } catch (e) {} }

    if (isIOS) {                                       /* iOS only speaks after one unlocking tap */
      var unlockSpeech = function () {
        try { var z = new window.SpeechSynthesisUtterance(''); z.volume = 0; oSpeak(z); } catch (e) {}
        document.removeEventListener('touchend', unlockSpeech, true);
        document.removeEventListener('click', unlockSpeech, true);
      };
      document.addEventListener('touchend', unlockSpeech, true);
      document.addEventListener('click', unlockSpeech, true);
    }
  }

  /* ---------- 1b. offline fallback: browsers with NO speechSynthesis (WhatsApp / Instagram / Facebook in-app browsers) ----------
     English is read with the bundled meSpeak engine (loaded only when needed). */
  if (!window.speechSynthesis) {
    var scr = document.currentScript, root = scr && scr.src ? scr.src.replace(/ttt-audio\.js.*$/, '') : 'assets/';
    var fbQ = [], fbBusy = false, fbReady = null, fbTok = 0, fbWarn = false;
    var load = function (src) { return new Promise(function (ok, no) { var s = document.createElement('script'); s.src = root + src; s.onload = ok; s.onerror = no; document.head.appendChild(s); }); };
    var ready = function () {
      if (fbReady) return fbReady;
      fbReady = load('mespeak-bundle.js').then(function () { return load('mespeak-config.js'); }).then(function () { return load('mespeak-en-us.js'); }).then(function () {
        window.meSpeak.loadConfig(window.MESPEAK_CONFIG); window.meSpeak.loadVoice(window.MESPEAK_EN_US);
      });
      return fbReady;
    };
    var pieces = function (t) {
      var p = String(t).match(/[^.!?\u0964\n]+[.!?\u0964]*\s*/g) || [String(t)], out = [], cur = '';
      p.forEach(function (x) { if (cur && (cur + x).length > 180) { out.push(cur); cur = x; } else cur += x; });
      if (cur.trim()) out.push(cur); return out;
    };
    var next = function () {
      if (fbBusy || !fbQ.length) return;
      var job = fbQ.shift(), tok = fbTok; fbBusy = true;
      var finish = function (err) { fbBusy = false; if (tok === fbTok) { if (err && job.u.onerror) job.u.onerror({ error: err }); else if (job.last && job.u.onend) job.u.onend({}); } next(); };
      ready().then(function () {
        if (tok !== fbTok) { finish(); return; }
        if (job.first && job.u.onstart) job.u.onstart({});
        try {
          window.meSpeak.speak(job.t, { speed: Math.max(80, Math.min(320, Math.round(175 * (job.u.rate || 1)))), pitch: 50, amplitude: Math.round(100 * (job.u.volume == null ? 1 : job.u.volume)) }, function (ok) { finish(ok ? null : 'synthesis-failed'); });
        } catch (e) { finish('synthesis-failed'); }
      }).catch(function () { finish('network'); });
    };
    window.SpeechSynthesisUtterance = function (text) { this.text = text || ''; this.lang = ''; this.rate = 1; this.pitch = 1; this.volume = 1; this.voice = null; };
    window.speechSynthesis = {
      speaking: false, paused: false, pending: false, onvoiceschanged: null,
      getVoices: function () { return []; },
      addEventListener: function () {}, removeEventListener: function () {},
      speak: function (u) {
        var lang = String(u.lang || document.documentElement.lang || 'en').toLowerCase();
        if (lang.indexOf('en') !== 0) {
          if (!fbWarn) { fbWarn = true; toast('This in-app browser cannot read ' + (NAMES_FB[lang.split('-')[0]] || 'this language') + ' aloud. Open this page in <b>Chrome</b> (menu &rarr; Open in browser) to hear it.'); }
          setTimeout(function () { if (u.onerror) u.onerror({ error: 'language-unavailable' }); }, 0); return;
        }
        var ps = pieces(u.text);
        ps.forEach(function (t, i) { fbQ.push({ t: t, u: u, first: i === 0, last: i === ps.length - 1 }); });
        next();
      },
      cancel: function () { fbTok++; fbQ.length = 0; try { if (window.meSpeak) window.meSpeak.stop(); } catch (e) {} fbBusy = false; },
      pause: function () {}, resume: function () {}
    };
    var NAMES_FB = { hi: 'Hindi', mr: 'Marathi', bn: 'Bengali', ta: 'Tamil', te: 'Telugu', gu: 'Gujarati' };
  }

  /* ---------- 2. Web Audio game sounds ---------- */
  var AC = window.AudioContext || window.webkitAudioContext;
  if (AC && !AC.__tttPatched) {
    var ctxs = [];
    var W = function (opts) {
      var c = (opts === undefined) ? new AC() : new AC(opts);
      ctxs.push(c);
      try { var p = c.resume && c.resume(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
      return c;
    };
    W.prototype = AC.prototype;
    try { Object.setPrototypeOf(W, AC); } catch (e) {}
    W.__tttPatched = true;
    window.AudioContext = W;
    window.webkitAudioContext = W;
    var unlock = function () {
      ctxs.forEach(function (c) {
        if (c.state === 'suspended' || c.state === 'interrupted') {
          try { var p = c.resume(); if (p && p.catch) p.catch(function () {}); } catch (e) {}
        }
      });
    };
    ['touchstart', 'touchend', 'pointerdown', 'click', 'keydown'].forEach(function (ev) {
      document.addEventListener(ev, unlock, { passive: true, capture: true });
    });
    document.addEventListener('visibilitychange', function () { if (!document.hidden) unlock(); });
  }
})();
