/* Teach Tech Toe - injects the shop.html style header + tabs on every page */
(function(){
 var s=document.currentScript,root=s?s.src.replace(/assets\/ttt-shopbar\.js.*$/,""):"";
 var here=decodeURIComponent(location.pathname.split("/").pop()||"index.html").toLowerCase();
 var T=[["Home","index.html"],["Courses","courses.html"],["Mock Tests","mocktest.html"],["Trainers","searchtrainers.html"],["Students","students.html"],["Downloads","downloads.html"]];
 function count(){try{return Object.values(JSON.parse(localStorage.getItem("ttt_cart")||"{}")).reduce(function(a,b){return a+b},0)}catch(e){return 0}}
 function init(){
  if(document.getElementById("tttBar"))return;
  var l=document.createElement("link");l.rel="stylesheet";l.href=root+"assets/ttt-shopbar.css";document.head.appendChild(l);
  if(!document.querySelector('link[href*="fonts.googleapis.com/css2?family=Poppins"]')){var f=document.createElement("link");f.rel="stylesheet";f.href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap";document.head.appendChild(f)}
  /* remove the page's old top header */
  var old=document.querySelectorAll("body > header, body > #header, #header, body > div > header, header#hd");
  old.forEach(function(h){if(h.id!=="tttBar"&&!h.closest(".modal,dialog,[role=dialog]"))h.remove()});
  var mm=document.getElementById("mobileMenu");if(mm)mm.remove();
  var b=document.createElement("header");b.id="tttBar";
  b.innerHTML='<div class="hw"><a class="logo" href="'+root+'index.html">🎓Teach-Tech-<b>Toe</b></a>'+
   '<nav class="tabs" id="tttTabs">'+T.map(function(t){return '<a class="'+(here==t[1]?"on":"")+'" href="'+root+t[1]+'">'+t[0]+'</a>'}).join("")+'</nav>'+
   '<a class="cartbtn" href="'+root+'shop.html">🛒 Basket <span id="tttCC">'+count()+'</span></a>'+
   '<button class="burger" id="tttBurger" aria-label="Menu">☰</button></div>';
  document.body.insertBefore(b,document.body.firstChild);
  document.getElementById("tttBurger").onclick=function(){document.getElementById("tttTabs").classList.toggle("open")};
  var p=function(){var c=document.getElementById("tttCC");if(c)c.textContent=count()};addEventListener("storage",p);addEventListener("pageshow",p);
 }
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
