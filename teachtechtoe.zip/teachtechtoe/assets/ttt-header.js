/* Shared mobile menu toggle for the unified header */
document.addEventListener("DOMContentLoaded",function(){
  var t=document.getElementById("mobileToggle"),m=document.getElementById("mobileMenu");
  if(!t||!m)return;
  t.addEventListener("click",function(e){e.stopPropagation();m.classList.toggle("active")});
  m.querySelectorAll("a").forEach(function(a){a.addEventListener("click",function(){m.classList.remove("active")})});
});