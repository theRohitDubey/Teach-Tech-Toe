/* Teach Tech Toe - site-wide connector: header, nav links, Home dock, basket */
(function(){
  var s=document.currentScript,root=s?s.src.replace(/assets\/ttt-nav\.js.*$/,""):"";
  var here=decodeURIComponent(location.pathname.split("/").pop()||"index.html").toLowerCase();
  var L=[
    ["🏠","Home","index.html"],["🤖","AI Lab","ai-lab.html"],["📚","Courses","courses.html"],["🛒","Course Shop","shop.html"],["📝","Mock Tests","mocktest.html"],
    ["💻","AI Mentor","ai-book-reader.html"],["⌨️","Online Compiler","onlinecompiler.html"],["🧭","Career Test","careertest.html"],["📄","Resume Builder","resumebuilder.html"],
    ["🎓","Teaching Studio","presentation.html"],["🔊","Text to Speech","aud.html"],["🔍","Search Trainers","searchtrainers.html"],
    ["👨‍🏫","For Trainers","trainers.html"],["🎓","For Students","students.html"],["⬇️","Downloads","downloads.html"],["💬","Free Counselling","counselling.html"],["📩","Enquiry","enq.html"],["🚀","Get Started","getstarted.html"]];
  function count(){try{return Object.values(JSON.parse(localStorage.getItem("ttt_cart")||"{}")).reduce(function(a,b){return a+b},0)}catch(e){return 0}}
  function on(h){return decodeURIComponent(h).split("/").pop().toLowerCase()===here}
  function css(){var c=document.createElement("style");c.textContent=
   "#tttDock{position:fixed;left:16px;bottom:16px;z-index:99998;font-family:Poppins,'Segoe UI',sans-serif}"+
   "#tttDock .b{display:inline-flex;align-items:center;gap:6px;background:#0b1220;color:#fff;border:0;border-radius:40px;padding:11px 18px;font:600 14px Poppins,sans-serif;text-decoration:none;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.35);transition:.2s}"+
   "#tttDock .b:hover{background:#ff6b1a;transform:translateY(-2px)}#tttDock .row{display:flex;gap:8px}"+
   "#tttMenu{position:absolute;left:0;bottom:56px;width:250px;max-height:70vh;overflow:auto;background:#fff;border-radius:16px;box-shadow:0 14px 40px rgba(0,0,0,.35);padding:8px;display:none}#tttMenu.open{display:block;animation:tttUp .2s}"+
   "#tttMenu a{display:flex;gap:10px;align-items:center;padding:9px 12px;border-radius:10px;color:#1e293b;text-decoration:none;font:500 13.5px Poppins,sans-serif}#tttMenu a:hover{background:#fff1e8;color:#e05600}#tttMenu a.cur{background:#ff6b1a;color:#fff}"+
   "#tttBasket{position:fixed;right:16px;bottom:16px;z-index:99998;background:#ff6b1a;color:#fff;padding:11px 18px;border-radius:40px;font:700 14px Poppins,sans-serif;text-decoration:none;box-shadow:0 8px 24px rgba(0,0,0,.35);display:flex;gap:8px;align-items:center;transition:.2s}#tttBasket:hover{transform:translateY(-2px);background:#e05600}"+
   "#tttBar{position:sticky;top:0;z-index:99990;background:#000;color:#fff;font-family:Poppins,'Segoe UI',sans-serif;box-shadow:0 4px 18px #0006}"+
   "#tttBar .in{max-width:1200px;margin:auto;padding:10px 16px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}"+
   "#tttBar a.brand{color:#fff;font-weight:800;text-decoration:none;white-space:nowrap}#tttBar a.brand b{color:#ff6b1a}"+
   "#tttBar nav{display:flex;gap:12px;flex-wrap:wrap;margin-left:auto}#tttBar nav a{color:#fff;text-decoration:none;font-size:13px;font-weight:500}#tttBar nav a:hover,#tttBar nav a.cur{color:#ff9800}"+
   "#tttBar .cta{background:#ff6b1a;color:#fff!important;padding:7px 14px;border-radius:999px;font-weight:700}"+
   "@keyframes tttUp{from{opacity:0;transform:translateY(8px)}}@media(max-width:480px){#tttDock .t{display:none}#tttBasket span.t{display:none}#tttBar nav{display:none}}";
   document.head.appendChild(c)}
  function favicon(){
    if(document.querySelector('link[rel="icon"]'))return;
    var l=document.createElement("link");l.rel="icon";l.type="image/svg+xml";l.href=root+"assets/img/favicon.svg";document.head.appendChild(l);
  }
  function injectHeader(){
    if(here=="shop.html")return;
    if(document.getElementById("header")||document.getElementById("tttBar")||document.querySelector(".site-header"))return;
    var bar=document.createElement("div");bar.id="tttBar";
    var links=[["Home","index.html"],["AI Lab","ai-lab.html"],["Courses","courses.html"],["Compiler","onlinecompiler.html"],["Tests","mocktest.html"],["Shop","shop.html"]];
    bar.innerHTML='<div class="in"><a class="brand" href="'+root+'index.html">🎓 Teach <b>Tech</b> Toe</a><nav>'+
      links.map(function(p){return '<a class="'+(on(p[1])?"cur":"")+'" href="'+root+p[1]+'">'+p[0]+'</a>'}).join("")+
      '<a class="cta" href="'+root+'enq.html">Book demo</a></nav></div>';
    document.body.insertBefore(bar,document.body.firstChild);
  }
  function init(){
    css();favicon();injectHeader();
    var ul=document.querySelector("#navmenu > ul")||document.querySelector(".navbar-nav")||document.querySelector("nav ul");
    if(ul){
      var have=(ul.innerHTML.toLowerCase());
      [["AI Lab","ai-lab.html"],["Home","index.html"],["Courses","courses.html"],["Course Shop","shop.html"],["Mock Tests","mocktest.html"],["Trainers","searchtrainers.html"],["Students","students.html"],["Downloads","downloads.html"]].forEach(function(p){
        if(have.indexOf(p[1])>-1)return;
        var li=document.createElement("li");li.className="nav-item";
        li.innerHTML='<a class="nav-link" href="'+root+p[1]+'"'+(p[1]=="shop.html"||p[1]=="ai-lab.html"?' style="color:#ff6b1a;font-weight:700"':'')+'>'+(p[1]=="shop.html"?"🛒 ":p[1]=="ai-lab.html"?"🤖 ":"")+p[0]+'</a>';
        ul.appendChild(li)});
      var a=ul.querySelectorAll("a[href]");for(var i=0;i<a.length;i++){if(on(a[i].getAttribute("href")||"")&&!a[i].closest(".dropdown")){a[i].classList.add("active")}}
    }
    var d=document.createElement("div");d.id="tttDock";
    var m='<div id="tttMenu">'+L.map(function(x){return '<a class="'+(on(x[2])?"cur":"")+'" href="'+root+x[2]+'"><span>'+x[0]+'</span>'+x[1]+'</a>'}).join("")+"</div>";
    d.innerHTML=m+'<div class="row"><a class="b" href="'+root+'index.html" title="Home">🏠 <span class="t">Home</span></a><button class="b" id="tttBtn" aria-label="Open site menu">☰ <span class="t">Menu</span></button></div>';
    document.body.appendChild(d);
    var btn=d.querySelector("#tttBtn"),menu=d.querySelector("#tttMenu");
    btn.onclick=function(e){e.stopPropagation();menu.classList.toggle("open")};
    document.addEventListener("click",function(e){if(!d.contains(e.target))menu.classList.remove("open")});
    document.addEventListener("keydown",function(e){if(e.key=="Escape")menu.classList.remove("open")});
    if(here!="shop.html"){
      var b=document.createElement("a");b.id="tttBasket";b.href=root+"shop.html";
      var paint=function(){var n=count();b.innerHTML='🛒 <span class="t">Course Shop</span>'+(n?' <span style="background:#fff;color:#ff6b1a;border-radius:20px;padding:0 8px">'+n+"</span>":"")};
      paint();document.body.appendChild(b);addEventListener("storage",paint);addEventListener("pageshow",paint)}
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",init);else init();
})();
