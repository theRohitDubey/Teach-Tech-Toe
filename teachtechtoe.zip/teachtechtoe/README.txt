HOW TO SHOW VIDEOS TO EVERY VISITOR
1. Copy your .mp4 files into this folder (assets/videos/).
2. Add one line per video in videos.json:
   { "title": "Python loops", "src": "assets/videos/python-loops.mp4", "topic": "web" }
   "src" can also be a YouTube link or a Google Drive link (shared as "Anyone with the link").
   Optional: "poster": "assets/videos/python-loops.jpg" for a cover image.
3. topic must be one of: office, english, exam, web, data, cloud, apps, biz

