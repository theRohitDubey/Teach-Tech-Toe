from __future__ import annotations

import os
import tempfile
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from faster_whisper import WhisperModel

app = FastAPI(title="Teach Tech Toe Faster-Whisper")
MODEL_NAME = os.getenv("WHISPER_MODEL", "small")
DEVICE = os.getenv("WHISPER_DEVICE", "cpu")
COMPUTE_TYPE = os.getenv("WHISPER_COMPUTE_TYPE", "int8")
model = WhisperModel(MODEL_NAME, device=DEVICE, compute_type=COMPUTE_TYPE)

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL_NAME, "device": DEVICE}

@app.post("/transcribe")
async def transcribe(audio: UploadFile = File(...), language: str = Form("en"), authorization: str | None = Header(default=None)):
    required = os.getenv("WHISPER_API_TOKEN", "")
    if required and authorization != "Bearer " + required:
        raise HTTPException(401, "Unauthorized.")
    suffix = Path(audio.filename or "recording.webm").suffix or ".webm"
    if suffix.lower() not in {".webm", ".wav", ".mp3", ".m4a", ".mp4", ".ogg", ".flac", ".mpeg"}:
        raise HTTPException(415, "Unsupported audio format.")
    size = 0
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            temp_path = tmp.name
            while chunk := await audio.read(1024 * 1024):
                size += len(chunk)
                if size > 25 * 1024 * 1024:
                    raise HTTPException(413, "Audio file is too large.")
                tmp.write(chunk)
        lang = language.split("-")[0].lower()
        if lang not in {"en", "hi", "auto"}:
            lang = "en"
        segments, _ = model.transcribe(temp_path, language=None if lang == "auto" else lang, vad_filter=True, beam_size=5)
        return {"text": " ".join(segment.text.strip() for segment in segments).strip()}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, "Transcription failed. Check the audio codec and model installation.") from exc
    finally:
        if "temp_path" in locals() and os.path.exists(temp_path):
            os.unlink(temp_path)
        await audio.close()
