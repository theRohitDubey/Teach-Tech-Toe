export const config = { rateLimit: { action: "rate_limit", aggregateBy: "ip", windowSize: 60, windowLimit: 12 } };

export default async (request) => {
  const json = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
  if (request.method !== "POST") return json({ error: "Use POST to transcribe audio." }, 405);
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return json({ error: "Cross-site requests are not allowed." }, 403);
  const base = (process.env.FASTER_WHISPER_URL || "").replace(/\/+$/, "");
  if (!base) return json({ error: "Faster-Whisper is not configured. Set FASTER_WHISPER_URL in the site environment." }, 503);
  let incoming;
  try { incoming = await request.formData(); } catch { return json({ error: "Choose an audio file first." }, 400); }
  const audio = incoming.get("audio");
  if (!(audio instanceof Blob) || !audio.size) return json({ error: "Choose an audio file first." }, 400);
  if (audio.size > 4 * 1024 * 1024) return json({ error: "This upload is over 4 MB. Compress it or use a shorter recording." }, 413);
  const form = new FormData();
  form.append("audio", audio, incoming.get("filename") || "recording.webm");
  form.append("language", incoming.get("language") || "en");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 55000);
  try {
    const headers = {};
    if (process.env.FASTER_WHISPER_TOKEN) headers.authorization = "Bearer " + process.env.FASTER_WHISPER_TOKEN;
    const response = await fetch(base + "/transcribe", { method: "POST", headers, body: form, signal: controller.signal });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: data.error || "Faster-Whisper could not transcribe this recording." }, 502);
    if (typeof data.text !== "string") return json({ error: "The transcription service returned an invalid response." }, 502);
    return json({ text: data.text });
  } catch (error) {
    return json({ error: error && error.name === "AbortError" ? "Transcription timed out. Try a shorter recording." : "Could not reach Faster-Whisper. Check FASTER_WHISPER_URL." }, error && error.name === "AbortError" ? 504 : 502);
  } finally { clearTimeout(timer); }
};
