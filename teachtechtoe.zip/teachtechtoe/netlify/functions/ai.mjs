export const config = { rateLimit: { action: "rate_limit", aggregateBy: "ip", windowSize: 60, windowLimit: 20 } };

export default async (request) => {
  const json = (payload, status = 200) => new Response(JSON.stringify(payload), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
  if (request.method !== "POST") return json({ error: "Use POST for AI requests." }, 405);
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return json({ error: "Cross-site AI requests are not allowed." }, 403);
  const raw = await request.text();
  if (raw.length > 30000) return json({ error: "Text is too long. Shorten it and retry." }, 413);
  let body;
  try { body = JSON.parse(raw); } catch { return json({ error: "The request body must be valid JSON." }, 400); }
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  const system = typeof body.system === "string" ? body.system.trim().slice(0, 3000) : "You are a helpful assistant. Be concise.";
  if (!prompt) return json({ error: "Enter text before starting." }, 400);
  if (prompt.length > 24000) return json({ error: "Text is too long. Shorten it and retry." }, 413);
  const base = (process.env.OLLAMA_BASE_URL || "").replace(/\/+$/, "");
  const model = process.env.OLLAMA_MODEL || "";
  if (!base || !model) return json({ error: "Ollama is not configured. Set OLLAMA_BASE_URL and OLLAMA_MODEL in the site environment." }, 503);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 55000);
  try {
    const headers = { "content-type": "application/json" };
    if (process.env.OLLAMA_API_TOKEN) headers.authorization = "Bearer " + process.env.OLLAMA_API_TOKEN;
    const response = await fetch(base + "/api/chat", { method: "POST", headers, body: JSON.stringify({ model, stream: false, messages: [{ role: "system", content: system }, { role: "user", content: prompt }], options: { temperature: 0.35, num_predict: 1200 } }), signal: controller.signal });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) return json({ error: response.status === 429 ? "Too many requests. Please wait a minute and retry." : "The Ollama service returned an error. Check that the model is installed and the server is reachable." }, response.status === 429 ? 429 : 502);
    const text = result.message && typeof result.message.content === "string" ? result.message.content.trim() : "";
    if (!text) return json({ error: "Ollama returned an empty response. Try again." }, 502);
    return json({ text });
  } catch (error) {
    if (error && error.name === "AbortError") return json({ error: "The AI request timed out. Try shorter text or a faster model." }, 504);
    return json({ error: "Could not reach Ollama. Check OLLAMA_BASE_URL and the server connection." }, 502);
  } finally { clearTimeout(timer); }
};
