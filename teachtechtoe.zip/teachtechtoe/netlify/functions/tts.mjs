export const config = { rateLimit: { action: "rate_limit", aggregateBy: "ip", windowSize: 60, windowLimit: 20 } };

export default async (request) => {
  const json = (value, status = 200) => new Response(JSON.stringify(value), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
  if (request.method !== "POST") return json({ error: "Use POST for speech synthesis." }, 405);
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return json({ error: "Cross-site requests are not allowed." }, 403);
  let body;
  try { body = await request.json(); } catch { return json({ error: "Invalid speech request." }, 400); }
  const text = typeof body.text === "string" ? body.text.trim() : "";
  if (!text) return json({ error: "Enter text to read." }, 400);
  if (text.length > 12000) return json({ error: "Text is too long for one audio request. Shorten it and retry." }, 413);
  const base = (process.env.PIPER_BASE_URL || "").replace(/\/+$/, "");
  if (!base) return json({ error: "Piper is not configured. Set PIPER_BASE_URL in the site environment." }, 503);
  const language = body.language === "hi-IN" ? "hi" : "en";
  const voice = language === "hi" ? process.env.PIPER_VOICE_HI : process.env.PIPER_VOICE_EN;
  const rate = Math.max(0.5, Math.min(2, Number(body.rate) || 1));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 55000);
  try {
    const headers = { "content-type": "application/json" };
    if (process.env.PIPER_API_TOKEN) headers.authorization = "Bearer " + process.env.PIPER_API_TOKEN;
    const response = await fetch(base + "/synthesize", { method: "POST", headers, body: JSON.stringify({ text, ...(voice ? { voice } : {}), length_scale: 1 / rate }), signal: controller.signal });
    if (!response.ok) return json({ error: "Piper returned an error. Check its voice model and server." }, 502);
    const audio = await response.arrayBuffer();
    if (!audio.byteLength) return json({ error: "Piper returned empty audio." }, 502);
    return new Response(audio, { headers: { "content-type": response.headers.get("content-type") || "audio/wav", "cache-control": "no-store" } });
  } catch (error) {
    return json({ error: error && error.name === "AbortError" ? "Speech synthesis timed out. Try less text." : "Could not reach Piper. Check PIPER_BASE_URL." }, error && error.name === "AbortError" ? 504 : 502);
  } finally { clearTimeout(timer); }
};
